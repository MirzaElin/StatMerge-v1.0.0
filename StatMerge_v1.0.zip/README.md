# StatMerge v1.0

Unified desktop app that opens two tools and includes a small data lab.

## Install
```bash
python -m pip install --upgrade pip
pip install PySide6 matplotlib numpy pandas scikit-learn python-docx
```

## Run
```bash
python StatMerge_v1.0_PySide6_Single.py
```

Then click **Open Statilytics Studio** or **Open EMTAS**.
